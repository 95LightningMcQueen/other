# Ряды Тейлора

Вычислить приближённое значение функции, используя её представление в виде ряда Тейлора. Вычисления заканчивать, когда очередное слагаемое окажется по модулю меньше заданного числа $\varepsilon$, где $0 < \varepsilon < 10^{-k}$, $k$ — натуральное число, $k > 1$. Сравнить полученный результат со значением, вычисленным с помощью стандартных математических функций. Значение $x$ и $\varepsilon$ ввести по запросу.

## Варианты

**1.** $e^{x}$

$$
e^{x} = 1 + \frac{x}{1!} + \frac{x^{2}}{2!} + \frac{x^{3}}{3!} + \ldots \qquad \forall x \in (-\infty; +\infty)
$$

---

**2.** $e^{-x}$

$$
e^{-x} = 1 - \frac{x}{1!} + \frac{x^{2}}{2!} - \frac{x^{3}}{3!} + \ldots \qquad \forall x \in (-\infty; +\infty)
$$

---

**3.** $\cos(x)$

$$
\cos(x) = 1 - \frac{x^{2}}{2!} + \frac{x^{4}}{4!} - \frac{x^{6}}{6!} + \ldots \qquad \forall x \in (-\infty; +\infty)
$$

---

**4.** $\ln(1-x)$

$$
\ln(1-x) = -x - \frac{x^{2}}{2} - \frac{x^{3}}{3} - \frac{x^{4}}{4} - \ldots \qquad \forall x \in [-1; 1)
$$

---

**5.** $\ln(1+x)$

$$
\ln(1+x) = x - \frac{x^{2}}{2} + \frac{x^{3}}{3} - \frac{x^{4}}{4} + \ldots \qquad \forall x \in (-1; +1]
$$

---

**6.** $\ln\dfrac{1+x}{1-x}$

$$
\ln\frac{1+x}{1-x} = 2\left(x + \frac{x^{3}}{3} + \frac{x^{5}}{5} + \frac{x^{7}}{7} + \ldots\right) \qquad \forall x \in (-1; +1)
$$

---

**7.** $\dfrac{1}{(1+x)^{2}}$

$$
\frac{1}{(1+x)^{2}} = 1 - \frac{2\cdot 3}{2}x + \frac{3\cdot 4}{2}x^{2} - \frac{4\cdot 5}{2}x^{3} + \ldots \qquad \forall x \in (-1; +1)
$$

---

**8.** $\sqrt{1+x}$

$$
\sqrt{1+x} = 1 + \frac{1}{2}x - \frac{1\cdot 2}{2\cdot 4}x^{2} + \frac{1\cdot 3}{2\cdot 4\cdot 6}x^{3} - \ldots \qquad \forall x \in (-1; +1)
$$

---

**9.** $\dfrac{1}{\sqrt{1+x}}$

$$
\frac{1}{\sqrt{1+x}} = 1 - \frac{1}{2}x + \frac{1\cdot 3}{2\cdot 4}x^{2} - \frac{1\cdot 3\cdot 5}{2\cdot 4\cdot 6}x^{3} + \ldots \qquad \forall x \in (-1; +1)
$$

---

**10.** $\dfrac{\sin(x)}{x}$

$$
\frac{\sin(x)}{x} = 1 - \frac{x^{2}}{3!} + \frac{x^{4}}{5!} - \frac{x^{6}}{7!} + \ldots \qquad \forall x \in (-\infty; +\infty)
$$

---

**11.** $\mathrm{sh}(x)$

$$
\mathrm{sh}(x) = \frac{e^{x} - e^{-x}}{2} = x + \frac{x^{3}}{3!} + \frac{x^{5}}{5!} + \ldots \qquad \forall x \in (-\infty; +\infty)
$$

---

**12.** $\mathrm{ch}(x)$

$$
\mathrm{ch}(x) = \frac{e^{x} + e^{-x}}{2} = 1 + \frac{x^{2}}{2!} + \frac{x^{4}}{4!} + \ldots \qquad \forall x \in (-\infty; +\infty)
$$

---

**13.** $\mathrm{arctg}(x)$

$$
\mathrm{arctg}(x) = \frac{\pi}{2} - x + \frac{x^{3}}{3} - \frac{x^{5}}{5} + \frac{x^{7}}{7} + \ldots \qquad \forall x \in (-1; +1)
$$

---

**14.** $\mathrm{arcctg}(x)$

$$
\mathrm{arcctg}(x) = \frac{\pi}{2} - \frac{1}{x} + \frac{1}{3x^{3}} - \frac{1}{5x^{5}} + \ldots \qquad \forall x > 1
$$

---

**15.** $\mathrm{arctg}(x)$

$$
\mathrm{arctg}(x) = x - \frac{x^{3}}{3} + \frac{x^{5}}{5} - \frac{x^{7}}{7} + \ldots \qquad \forall x \in (-1; +1)
$$

---

**16.** $\mathrm{arth}(x)$

$$
\mathrm{arth}(x) = x + \frac{x^{3}}{3} + \frac{x^{5}}{5} + \frac{x^{7}}{7} + \ldots \qquad \forall x \in (-1; +1)
$$

---

**17.** $\sin(x)$

$$
\sin(x) = x - \frac{x^{3}}{3!} + \frac{x^{5}}{5!} - \frac{x^{7}}{7!} + \ldots \qquad \forall x \in (-\infty; +\infty)
$$
