# Перенос C++-лабораторных на Python

## 0. Постановка задачи

Перепишите на Python лабораторные работы, которые вы выполняли на C++. Цель — не получить «тот же код в другом синтаксисе», а освоить примитивы Python: ветвление и циклы, `list`, `str`, стандартные модули, ввод/вывод, функции.

---

## 1. Список лабораторных работ

| Работа | Тема | Что осваиваем при переносе |
|---|---|---|
| [01-taylor](01-taylor/README.md) | Ряды Тейлора | циклы, `float`, модуль `math` |
| [02-arithmetics](02-arithmetics/README.md) | Целочисленная арифметика | `//` и `%`, `range`, декомпозиция на функции |
| [03-arrays-static](03-arrays-static/README.md) | Одномерные массивы | `list` вместо массива фиксированного размера |
| [04-arrays-dynamic](04-arrays-dynamic/README.md) | Матрицы | вложенные списки, итерирование по элементам, а не по индексам |
| [05-funcs-intro](05-funcs-intro/README.md) | Функции | определение функций, `return`, булевы выражения, модуль `math` |
| [06-strings-cstyle](06-strings-cstyle/README.md) | Нуль-терминированные строки | неизменяемый `str`: для модификаций — `list` символов |
| [07-strings-cppstyle](07-strings-cppstyle/README.md) | `std::string` и его методы | методы `str`, `split`/`join`, f-строки |
| [08-files-txt](08-files-txt/README.md) | Текстовые файлы | `open`, контекстный менеджер `with`, построчная обработка |
| [09-files-binary](09-files-binary/README.md) | Бинарные файлы | бинарный режим, сериализация через `struct`/`pickle` |
| [10-ds-linear](10-ds-linear/README.md) | Линейные структуры данных | `list` и `collections.deque` вместо списков вручную |
| [11-funcs-templates](11-funcs-templates/README.md) | Шаблоны и перегрузка функций | утиная типизация и дженерики (`TypeVar`, `Protocol`) вместо шаблонов |
| [12-classes-intro](12-classes-intro/README.md) | Введение в классы | класс и `__init__`; зачем в Python не нужны конструктор копирования и деструктор |
| [13-classes-operators](13-classes-operators/README.md) | Перегрузка операторов | dunder-методы, `@dataclass`, контракты операторов |
| [14-classes-inheritance](14-classes-inheritance/README.md) | Наследование и полиморфизм | наследование, `ABC`, MRO и `super()` |
| [15-classes-templates](15-classes-templates/README.md) | Шаблоны классов | стандартные `list`/`deque`/`dict` вместо самописных контейнеров, `Protocol` |
| [16-containers-seq](16-containers-seq/README.md) | Последовательные контейнеры STL | `list` и `collections.deque`: `append`/`insert`/`pop`, итераторы |
| [17-containers-assoc](17-containers-assoc/README.md) | Ассоциативные контейнеры STL | `dict` и `set`, их методы |
| [18-classes-algorithms](18-classes-algorithms/README.md) | Отношения между классами, алгоритмы STL | композиция, `sorted`/`min`/`any` и `key=` |
| [19-json-check](19-json-check/README.md) | Проверка структуры JSON | `json`, валидация структуры, type hints |
| [20-json-modify](20-json-modify/README.md) | Изменение структуры JSON | `json` + операции над `dict`/`list` |
| [21-json-datetime](21-json-datetime/README.md) | Сериализация даты и времени | `datetime`, сериализация в `json` |
| [22-json-fs-info](22-json-fs-info/README.md) | Информация об объектах ФС в JSON | `pathlib`, `json` |
| [23-fs-info-extract](23-fs-info-extract/README.md) | Извлечение информации об объектах ФС | `pathlib`, разбор аргументов командной строки, форматированный вывод |
| [24-fs-copy](24-fs-copy/README.md) | Копирование с сравнением по содержимому | `pathlib`, `shutil`, `set` |
| [25-fs-copy-class](25-fs-copy-class/README.md) | То же классовым подходом | инкапсуляция состояния в классе |
| [26-fs-remove-duplicates](26-fs-remove-duplicates/README.md) | Удаление дубликатов по контрольной сумме | `hashlib`, операции над файлами |
| [27-fs-move-by-date](27-fs-move-by-date/README.md) | Перемещение файлов по дате в имени | `pathlib`, `shutil`, `str.split`/`re` |
| [28-fs-move-with-remove](28-fs-move-with-remove/README.md) | Перемещение + удаление по правилу | разбор имени файла классом, `dataclass` |
| [29-xor-encrypt](29-xor-encrypt/README.md) | Шифрование наложением гаммы (XOR) | `bytes`/`bytearray`, модуль `random` |
| [30-xor-encrypt-class](30-xor-encrypt-class/README.md) | То же классовым подходом | класс с `random.Random` как состояние |
| [31-generators-bench](31-generators-bench/README.md) | Сравнение производительности генераторов | `timeit`/`perf_counter`, сравнение `random` и `secrets` |

---

## 2. Что переносится, а что нет

- **Переносится как есть:** алгоритмическая постановка из условия, требования к вводу/выводу и ваш вариант.
- **Не переносится:** привязка к механизмам C++ — именованная константа максимального размера массива, `char *`, `std::string`, ручное управление памятью. Питоновский эквивалент выбираете сами и готовитесь обосновать выбор на защите.
- **Из старых условий переносятся общие требования** (кроме явно противоречащих Python): два способа заполнения данными (с клавиатуры и датчиком случайных чисел с вводом границ интервала), контроль корректности ввода, вывод результатов, а также сообщение, если решение невозможно. Запрет на дополнительные массивы при преобразовании данных (работы 03, 04) сохраняется — переформулируйте его для `list`.

---

## 3. Требования к сдаче

- Решение каждой лаборатории — самодостаточный запускаемый скрипт (или пакет) в папке соответствующей лабораторной работе, например `01-taylor/main.py`.
- Дословный перенос C++-кода (`for i in range(len(a))`, ручные счётчики вместо `enumerate`, конкатенация строк в цикле) считается ошибкой переноса.
- Пишите код функциями сразу.
